# Test cases - BR1 BUYPASS ATL105 MasterCard Credit

Build `buypass-atl105-mastercard-credit-65482e4498`; mapping status **candidate**; merchants: **placeholder**; catalog `config/transaction_testcases.json` 2026-10-28.1.

Transaction-level test cases: each is a business transaction or flow run end to end. The spec's data-element rules are checked inside every step (rule checks); device rules are checkpoints. The test data is the request of each step; the expected response is on the test case, per step.

Naming: BR = `{Platform} {Spec} {Network} {Program}`; scenario = `{BR} {Transaction Category} – {Entry Mode}`; test case = `{BR} {Merchant} {Transaction Category} – {Entry Mode} {flow} → {outcome}`.

## Summary

| Measure | Value |
|---|---|
| Scenarios | 36 |
| Test cases | 241 |
| By status | ready: 125, needs_client_input: 47, requires_review: 35, pending_sme: 32, blocked_spec_gap: 2 |
| By polarity | Positive: 226, Negative: 15 |
| Verification | PASS: 232, NOT_APPLICABLE: 9 |
| Response code tiers | ASSERT: 89, FLAG: 143, N/A: 9 |
| Scenarios with test cases | 36 / 36 |
| Validation | passed |

## By type

| Type | Test cases |
|---|---|
| T1 Base transaction | 36 |
| T2 Card capture path | 12 |
| T3 Cardholder verification | 6 |
| T4 Partial approval | 42 |
| T5 Follow-on lifecycle | 54 |
| T6 Time-out & recovery | 50 |
| T7 Stored credential | 5 |
| T8 Settlement | 7 |
| T9 Value-added service | 14 |
| T10 Business-rule decline | 8 |
| T11 Device-only | 7 |

## BR1 BUYPASS ATL105 MasterCard Credit


### BR1_TS1 BUYPASS ATL105 MasterCard Credit Purchase/Capture – EMV Contact Chip (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS1_TC1 | TC-002201 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Purchase approved | T1 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS1_TC2 | TC-002202 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Expired EMV card → sent online → host decides | T2 | 0 | 1: 1 (FLAG) | needs_client_input |
| BR1_TS1_TC3 | TC-002203 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip EMV online PIN → approved | T3 | 0 | 1: 0 (ASSERT) | needs_client_input |
| BR1_TS1_TC4 | TC-002204 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip EMV offline PIN → approved | T3 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS1_TC5 | TC-002205 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Partial approval → remainder on 2nd card (split tender) | T4 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS1_TC6 | TC-002206 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Partial approval → Purchase Reversal of approved amount | T4 | 0 -> 8 | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS1_TC7 | TC-002207 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Partial approval → Time-out Reversal | T4 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | requires_review |
| BR1_TS1_TC8 | TC-002208 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Partial not supported (indicator 0) → full approval or decline | T4 | 0 | 1: 1 (FLAG) | needs_client_input |
| BR1_TS1_TC9 | TC-002209 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Purchase → Purchase Reversal | T5 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS1_TC10 | TC-002210 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Purchase, no response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS1_TC11 | TC-002211 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Purchase, late approval → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS1_TC12 | TC-002212 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Purchase, unreadable response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS1_TC13 | TC-002213 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Purchase timed out → TOR sent ahead of next Purchase | T6 | 0 -> Z -> 0 | 1: no response expected ; 2: 0 (FLAG) ; 3: 0 (ASSERT) | ready |
| BR1_TS1_TC14 | TC-002214 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip Time-out Reversal unanswered → retried (max 3) | T6 | 0 -> Z -> Z -> Z | 1: no response expected ; 2: no response expected ; 3: no response expected ; 4: 0 (FLAG) | ready |
| BR1_TS1_TC15 | TC-002215 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip FSA/HRA healthcare purchase → approved | T9 | 0 | 1: 0 (ASSERT) | needs_client_input |
| BR1_TS1_TC16 | TC-002216 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contact Chip FSA/HRA partial approval → split tender | T9 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |

### BR1_TS2 BUYPASS ATL105 MasterCard Credit Purchase/Capture – EMV Contactless Chip (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS2_TC1 | TC-002217 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Purchase approved | T1 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS2_TC2 | TC-002218 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Contactless chip → contact chip (86) → approved | T2 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS2_TC3 | TC-002219 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Expired EMV card → sent online → host decides | T2 | 0 | 1: 1 (FLAG) | needs_client_input |
| BR1_TS2_TC4 | TC-002220 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip EMV online PIN → approved | T3 | 0 | 1: 0 (ASSERT) | needs_client_input |
| BR1_TS2_TC5 | TC-002221 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Partial approval → remainder on 2nd card (split tender) | T4 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS2_TC6 | TC-002222 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Partial approval → Purchase Reversal of approved amount | T4 | 0 -> 8 | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS2_TC7 | TC-002223 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Partial approval → Time-out Reversal | T4 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | requires_review |
| BR1_TS2_TC8 | TC-002224 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Partial not supported (indicator 0) → full approval or decline | T4 | 0 | 1: 1 (FLAG) | needs_client_input |
| BR1_TS2_TC9 | TC-002225 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Purchase → Purchase Reversal | T5 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS2_TC10 | TC-002226 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Purchase, no response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS2_TC11 | TC-002227 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Purchase, late approval → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS2_TC12 | TC-002228 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Purchase, unreadable response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS2_TC13 | TC-002229 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Purchase timed out → TOR sent ahead of next Purchase | T6 | 0 -> Z -> 0 | 1: no response expected ; 2: 0 (FLAG) ; 3: 0 (ASSERT) | ready |
| BR1_TS2_TC14 | TC-002230 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip Time-out Reversal unanswered → retried (max 3) | T6 | 0 -> Z -> Z -> Z | 1: no response expected ; 2: no response expected ; 3: no response expected ; 4: 0 (FLAG) | ready |
| BR1_TS2_TC15 | TC-002231 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip FSA/HRA healthcare purchase → approved | T9 | 0 | 1: 0 (ASSERT) | needs_client_input |
| BR1_TS2_TC16 | TC-002232 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – EMV Contactless Chip FSA/HRA partial approval → split tender | T9 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |

### BR1_TS3 BUYPASS ATL105 MasterCard Credit Purchase/Capture – Magnetic Stripe (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS3_TC1 | TC-002233 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase approved | T1 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS3_TC2 | TC-002234 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Track 2 unreadable → Track 1 sent → approved | T2 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS3_TC3 | TC-002235 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Swiped/keyed at RFID-equipped terminal → approved | T2 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS3_TC4 | TC-002236 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Partial approval → remainder on 2nd card (split tender) | T4 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS3_TC5 | TC-002237 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Partial approval → Purchase Reversal of approved amount | T4 | 0 -> 8 | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS3_TC6 | TC-002238 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Partial approval → Time-out Reversal | T4 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | requires_review |
| BR1_TS3_TC7 | TC-002239 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Partial not supported (indicator 0) → full approval or decline | T4 | 0 | 1: 1 (FLAG) | needs_client_input |
| BR1_TS3_TC8 | TC-002240 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase → Purchase Reversal | T5 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS3_TC9 | TC-002241 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase, no response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS3_TC10 | TC-002242 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase, late approval → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS3_TC11 | TC-002243 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase, unreadable response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS3_TC12 | TC-002244 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase timed out → TOR sent ahead of next Purchase | T6 | 0 -> Z -> 0 | 1: no response expected ; 2: 0 (FLAG) ; 3: 0 (ASSERT) | ready |
| BR1_TS3_TC13 | TC-002245 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Time-out Reversal unanswered → retried (max 3) | T6 | 0 -> Z -> Z -> Z | 1: no response expected ; 2: no response expected ; 3: no response expected ; 4: 0 (FLAG) | ready |
| BR1_TS3_TC14 | TC-002246 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase → Settlement (read and cut 222222) | T8 | 0 -> 990 | 1: 0 (ASSERT) ; 2: ? (FLAG) | requires_review |
| BR1_TS3_TC15 | TC-002247 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase → Purchase Reversal → Settlement | T8 | 0 -> 8 -> 990 | 1: 0 (ASSERT) ; 2: 0 (FLAG) ; 3: ? (FLAG) | requires_review |
| BR1_TS3_TC16 | TC-002248 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase + Merchandise Return → Settlement | T8 | 0 -> 7 -> 990 | 1: 0 (ASSERT) ; 2: ? (FLAG) ; 3: ? (FLAG) | requires_review |
| BR1_TS3_TC17 | TC-002249 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase timed out → TOR → Settlement | T8 | 0 -> Z -> 990 | 1: no response expected ; 2: 0 (FLAG) ; 3: ? (FLAG) | requires_review |
| BR1_TS3_TC18 | TC-002250 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase → Read-only totals (333333) | T8 | 0 -> 990 | 1: 0 (ASSERT) ; 2: ? (FLAG) | ready |
| BR1_TS3_TC19 | TC-002251 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase → Auto-close at cut time | T8 | 0 -> 990 | 1: 0 (ASSERT) ; 2: ? (FLAG) | requires_review |
| BR1_TS3_TC20 | TC-002252 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe FSA/HRA healthcare purchase → approved | T9 | 0 | 1: 0 (ASSERT) | needs_client_input |
| BR1_TS3_TC21 | TC-002253 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe FSA/HRA partial approval → split tender | T9 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS3_TC22 | TC-002254 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Time-out Reversal with no original → declined (unmatched) | T10 | Z | 1: 1 (ASSERT) | ready |
| BR1_TS3_TC23 | TC-002255 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Purchase → Reversal → Time-out Reversal → declined | T10 | 0 -> 8 -> Z | 1: 0 (ASSERT) ; 2: 0 (FLAG) ; 3: 1 (ASSERT) | ready |
| BR1_TS3_TC24 | TC-002256 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Partial approval → Reversal of requested amount → declined | T10 | 0 -> 8 | 1: F (ASSERT) ; 2: 1 (FLAG) | requires_review |
| BR1_TS3_TC25 | TC-002257 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Cashback on MasterCard credit → declined | T10 | 0 | 1: 1 (FLAG) | requires_review |
| BR1_TS3_TC26 | TC-002258 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Magnetic Stripe Expired card → rejected at device (no host message) | T11 | - | n/a (no host message) | ready |

### BR1_TS4 BUYPASS ATL105 MasterCard Credit Purchase/Capture – Contactless Magnetic Stripe (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS4_TC1 | TC-002259 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Purchase approved | T1 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS4_TC2 | TC-002260 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Partial approval → remainder on 2nd card (split tender) | T4 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS4_TC3 | TC-002261 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Partial approval → Purchase Reversal of approved amount | T4 | 0 -> 8 | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS4_TC4 | TC-002262 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Partial approval → Time-out Reversal | T4 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | requires_review |
| BR1_TS4_TC5 | TC-002263 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Partial not supported (indicator 0) → full approval or decline | T4 | 0 | 1: 1 (FLAG) | needs_client_input |
| BR1_TS4_TC6 | TC-002264 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Purchase → Purchase Reversal | T5 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS4_TC7 | TC-002265 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Purchase, no response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS4_TC8 | TC-002266 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Purchase, late approval → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS4_TC9 | TC-002267 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Purchase, unreadable response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS4_TC10 | TC-002268 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Purchase timed out → TOR sent ahead of next Purchase | T6 | 0 -> Z -> 0 | 1: no response expected ; 2: 0 (FLAG) ; 3: 0 (ASSERT) | ready |
| BR1_TS4_TC11 | TC-002269 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Time-out Reversal unanswered → retried (max 3) | T6 | 0 -> Z -> Z -> Z | 1: no response expected ; 2: no response expected ; 3: no response expected ; 4: 0 (FLAG) | ready |
| BR1_TS4_TC12 | TC-002270 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Magnetic Stripe Expired card → rejected at device (no host message) | T11 | - | n/a (no host message) | ready |

### BR1_TS5 BUYPASS ATL105 MasterCard Credit Purchase/Capture – Manual / Keyed (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS5_TC1 | TC-002271 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Purchase approved | T1 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS5_TC2 | TC-002272 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed 3 failed swipes → keyed entry → approved | T2 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS5_TC3 | TC-002273 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Swiped/keyed at RFID-equipped terminal → approved | T2 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS5_TC4 | TC-002274 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Partial approval → remainder on 2nd card (split tender) | T4 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS5_TC5 | TC-002275 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Partial approval → Purchase Reversal of approved amount | T4 | 0 -> 8 | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS5_TC6 | TC-002276 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Partial approval → Time-out Reversal | T4 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | requires_review |
| BR1_TS5_TC7 | TC-002277 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Partial not supported (indicator 0) → full approval or decline | T4 | 0 | 1: 1 (FLAG) | needs_client_input |
| BR1_TS5_TC8 | TC-002278 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Purchase → Purchase Reversal | T5 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS5_TC9 | TC-002279 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Purchase, no response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS5_TC10 | TC-002280 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Purchase, late approval → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS5_TC11 | TC-002281 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Purchase, unreadable response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS5_TC12 | TC-002282 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Purchase timed out → TOR sent ahead of next Purchase | T6 | 0 -> Z -> 0 | 1: no response expected ; 2: 0 (FLAG) ; 3: 0 (ASSERT) | ready |
| BR1_TS5_TC13 | TC-002283 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Time-out Reversal unanswered → retried (max 3) | T6 | 0 -> Z -> Z -> Z | 1: no response expected ; 2: no response expected ; 3: no response expected ; 4: 0 (FLAG) | ready |
| BR1_TS5_TC14 | TC-002284 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Purchase with AVS mismatch → approved | T9 | 0 | 1: 0 (ASSERT) | needs_client_input |
| BR1_TS5_TC15 | TC-002285 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Purchase with AVS mismatch → merchant reverses | T9 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS5_TC16 | TC-002286 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Expired card → rejected at device (no host message) | T11 | - | n/a (no host message) | ready |
| BR1_TS5_TC17 | TC-002287 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Manual / Keyed Keyed entry before 3 swipes → refused at device | T11 | - | n/a (no host message) | requires_review |

### BR1_TS6 BUYPASS ATL105 MasterCard Credit Purchase/Capture – Chip Fallback (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS6_TC1 | TC-002288 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Purchase approved | T1 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS6_TC2 | TC-002289 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Chip unreadable → keyed fallback (79) → approved | T2 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS6_TC3 | TC-002290 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Partial approval → remainder on 2nd card (split tender) | T4 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS6_TC4 | TC-002291 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Partial approval → Purchase Reversal of approved amount | T4 | 0 -> 8 | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS6_TC5 | TC-002292 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Partial approval → Time-out Reversal | T4 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | requires_review |
| BR1_TS6_TC6 | TC-002293 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Partial not supported (indicator 0) → full approval or decline | T4 | 0 | 1: 1 (FLAG) | needs_client_input |
| BR1_TS6_TC7 | TC-002294 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Purchase → Purchase Reversal | T5 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS6_TC8 | TC-002295 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Purchase, no response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS6_TC9 | TC-002296 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Purchase, late approval → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS6_TC10 | TC-002297 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Purchase, unreadable response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS6_TC11 | TC-002298 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Purchase timed out → TOR sent ahead of next Purchase | T6 | 0 -> Z -> 0 | 1: no response expected ; 2: 0 (FLAG) ; 3: 0 (ASSERT) | ready |
| BR1_TS6_TC12 | TC-002299 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Chip Fallback Time-out Reversal unanswered → retried (max 3) | T6 | 0 -> Z -> Z -> Z | 1: no response expected ; 2: no response expected ; 3: no response expected ; 4: 0 (FLAG) | ready |

### BR1_TS7 BUYPASS ATL105 MasterCard Credit Purchase/Capture – Credential on File (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS7_TC1 | TC-002300 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Purchase approved | T1 | 0 | 1: 0 (ASSERT) | ready |
| BR1_TS7_TC2 | TC-002301 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Purchase → Purchase Reversal | T5 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS7_TC3 | TC-002302 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Purchase, no response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS7_TC4 | TC-002303 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Purchase, late approval → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS7_TC5 | TC-002304 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Purchase, unreadable response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS7_TC6 | TC-002305 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Purchase timed out → TOR sent ahead of next Purchase | T6 | 0 -> Z -> 0 | 1: no response expected ; 2: 0 (FLAG) ; 3: 0 (ASSERT) | ready |
| BR1_TS7_TC7 | TC-002306 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Time-out Reversal unanswered → retried (max 3) | T6 | 0 -> Z -> Z -> Z | 1: no response expected ; 2: no response expected ; 3: no response expected ; 4: 0 (FLAG) | ready |
| BR1_TS7_TC8 | TC-002307 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Store card (cardholder-initiated) → repeat cardholder-initiated purchase | T7 | 0 -> 0 | 1: 0 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS7_TC9 | TC-002308 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File $0.00 Account Verification → merchant-initiated purchase | T7 | A -> 0 | 1: 0 (FLAG) ; 2: 0 (ASSERT) | requires_review |
| BR1_TS7_TC10 | TC-002309 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Recurring standing order: first → merchant-initiated repeat | T7 | 0 -> 0 | 1: 0 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS7_TC11 | TC-002310 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Recurring subscription: first → merchant-initiated repeat | T7 | 0 -> 0 | 1: 0 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS7_TC12 | TC-002311 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Installment: first → merchant-initiated installment | T7 | 0 -> 0 | 1: 0 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS7_TC13 | TC-002312 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Purchase with AVS mismatch → approved | T9 | 0 | 1: 0 (ASSERT) | needs_client_input |
| BR1_TS7_TC14 | TC-002313 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Credential on File Purchase with AVS mismatch → merchant reverses | T9 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | needs_client_input |

### BR1_TS8 BUYPASS ATL105 MasterCard Credit Purchase/Capture – Contactless Mobile Commerce Device (unconfirmed)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS8_TC1 | TC-002314 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Purchase approved | T1 | 0 | 1: 0 (ASSERT) | pending_sme |
| BR1_TS8_TC2 | TC-002315 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Partial approval → remainder on 2nd card (split tender) | T4 | 0 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | pending_sme |
| BR1_TS8_TC3 | TC-002316 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Partial approval → Purchase Reversal of approved amount | T4 | 0 -> 8 | 1: F (ASSERT) ; 2: 0 (FLAG) | pending_sme |
| BR1_TS8_TC4 | TC-002317 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Partial approval → Time-out Reversal | T4 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | pending_sme |
| BR1_TS8_TC5 | TC-002318 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Partial not supported (indicator 0) → full approval or decline | T4 | 0 | 1: 1 (FLAG) | pending_sme |
| BR1_TS8_TC6 | TC-002319 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Purchase → Purchase Reversal | T5 | 0 -> 8 | 1: 0 (ASSERT) ; 2: 0 (FLAG) | pending_sme |
| BR1_TS8_TC7 | TC-002320 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Purchase, no response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | pending_sme |
| BR1_TS8_TC8 | TC-002321 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Purchase, late approval → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | pending_sme |
| BR1_TS8_TC9 | TC-002322 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Purchase, unreadable response → Time-out Reversal | T6 | 0 -> Z | 1: no response expected ; 2: 0 (FLAG) | pending_sme |
| BR1_TS8_TC10 | TC-002323 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Purchase timed out → TOR sent ahead of next Purchase | T6 | 0 -> Z -> 0 | 1: no response expected ; 2: 0 (FLAG) ; 3: 0 (ASSERT) | pending_sme |
| BR1_TS8_TC11 | TC-002324 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Purchase/Capture – Contactless Mobile Commerce Device Time-out Reversal unanswered → retried (max 3) | T6 | 0 -> Z -> Z -> Z | 1: no response expected ; 2: no response expected ; 3: no response expected ; 4: 0 (FLAG) | pending_sme |

### BR1_TS9 BUYPASS ATL105 MasterCard Credit Mail/Phone Purchase – Manual / Keyed (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS9_TC1 | TC-002325 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Manual / Keyed Mail/Phone Purchase approved | T1 | 6 | 1: ? (FLAG) | ready |
| BR1_TS9_TC2 | TC-002326 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Manual / Keyed Mail/Phone Purchase → Mail/Phone Reversal | T5 | 6 -> C | 1: ? (FLAG) ; 2: 0 (FLAG) | ready |
| BR1_TS9_TC3 | TC-002327 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Manual / Keyed Mail/Phone Purchase, no response → Time-out Reversal | T6 | 6 -> Z | 1: no response expected ; 2: 0 (FLAG) | ready |
| BR1_TS9_TC4 | TC-002328 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Manual / Keyed Mail/Phone Purchase with AVS mismatch → approved | T9 | 6 | 1: 0 (ASSERT) | needs_client_input |
| BR1_TS9_TC5 | TC-002329 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Manual / Keyed Mail/Phone Purchase with AVS mismatch → Mail/Phone Reversal | T9 | 6 -> C | 1: 0 (ASSERT) ; 2: 0 (FLAG) | requires_review |
| BR1_TS9_TC6 | TC-002330 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Manual / Keyed Partial requested on Mail/Phone Purchase → not partially approved | T10 | 6 | 1: 1 (FLAG) | requires_review |

### BR1_TS10 BUYPASS ATL105 MasterCard Credit Mail/Phone Purchase – Credential on File (unconfirmed)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS10_TC1 | TC-002331 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Credential on File Mail/Phone Purchase approved | T1 | 6 | 1: ? (FLAG) | pending_sme |
| BR1_TS10_TC2 | TC-002332 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Credential on File Mail/Phone Purchase → Mail/Phone Reversal | T5 | 6 -> C | 1: ? (FLAG) ; 2: 0 (FLAG) | pending_sme |
| BR1_TS10_TC3 | TC-002333 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Credential on File Mail/Phone Purchase, no response → Time-out Reversal | T6 | 6 -> Z | 1: no response expected ; 2: 0 (FLAG) | pending_sme |
| BR1_TS10_TC4 | TC-002334 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Credential on File Mail/Phone Purchase with AVS mismatch → approved | T9 | 6 | 1: 0 (ASSERT) | pending_sme |
| BR1_TS10_TC5 | TC-002335 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Purchase – Credential on File Mail/Phone Purchase with AVS mismatch → Mail/Phone Reversal | T9 | 6 -> C | 1: 0 (ASSERT) ; 2: 0 (FLAG) | pending_sme |

### BR1_TS11 BUYPASS ATL105 MasterCard Credit Authorization Only – EMV Contact Chip (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS11_TC1 | TC-002336 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip Authorization Only approved | T1 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS11_TC2 | TC-002337 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip EMV online PIN → approved | T3 | 3 | 1: 2 (ASSERT) | needs_client_input |
| BR1_TS11_TC3 | TC-002338 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip EMV offline PIN → approved | T3 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS11_TC4 | TC-002339 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip Partial authorization → Completion for approved amount | T4 | 3 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS11_TC5 | TC-002340 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip Partial authorization → Cancellation | T4 | 3 -> S | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS11_TC6 | TC-002341 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip Authorization → Completion | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS11_TC7 | TC-002342 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip Pre-authorization → Completion for a different final amount | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (FLAG) | requires_review |
| BR1_TS11_TC8 | TC-002343 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip Authorization → Cancellation | T5 | 3 -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS11_TC9 | TC-002344 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip Authorization → Completion → Purchase Reversal | T5 | 3 -> 0 -> 8 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: 0 (FLAG) | ready |
| BR1_TS11_TC10 | TC-002345 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contact Chip Completion timed out → Time-out Reversal → Completion resubmitted | T6 | 3 -> 0 -> Z -> 0 | 1: 2 (ASSERT) ; 2: no response expected ; 3: 0 (FLAG) ; 4: 0 (ASSERT) | requires_review |

### BR1_TS12 BUYPASS ATL105 MasterCard Credit Authorization Only – EMV Contactless Chip (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS12_TC1 | TC-002346 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Authorization Only approved | T1 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS12_TC2 | TC-002347 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Contactless chip → contact chip (86) → approved | T2 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS12_TC3 | TC-002348 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip EMV online PIN → approved | T3 | 3 | 1: 2 (ASSERT) | needs_client_input |
| BR1_TS12_TC4 | TC-002349 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Partial authorization → Completion for approved amount | T4 | 3 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS12_TC5 | TC-002350 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Partial authorization → Cancellation | T4 | 3 -> S | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS12_TC6 | TC-002351 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Authorization → Completion | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS12_TC7 | TC-002352 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Pre-authorization → Completion for a different final amount | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (FLAG) | requires_review |
| BR1_TS12_TC8 | TC-002353 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Authorization → Cancellation | T5 | 3 -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS12_TC9 | TC-002354 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Authorization → Completion → Purchase Reversal | T5 | 3 -> 0 -> 8 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: 0 (FLAG) | ready |
| BR1_TS12_TC10 | TC-002355 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – EMV Contactless Chip Completion timed out → Time-out Reversal → Completion resubmitted | T6 | 3 -> 0 -> Z -> 0 | 1: 2 (ASSERT) ; 2: no response expected ; 3: 0 (FLAG) ; 4: 0 (ASSERT) | requires_review |

### BR1_TS13 BUYPASS ATL105 MasterCard Credit Authorization Only – Magnetic Stripe (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS13_TC1 | TC-002356 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Authorization Only approved | T1 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS13_TC2 | TC-002357 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Track 2 unreadable → Track 1 sent → approved | T2 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS13_TC3 | TC-002358 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Partial authorization → Completion for approved amount | T4 | 3 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS13_TC4 | TC-002359 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Partial authorization → Cancellation | T4 | 3 -> S | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS13_TC5 | TC-002360 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Authorization → Completion | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS13_TC6 | TC-002361 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Pre-authorization → Completion for a different final amount | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (FLAG) | requires_review |
| BR1_TS13_TC7 | TC-002362 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Authorization → Cancellation | T5 | 3 -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS13_TC8 | TC-002363 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Authorization → Completion → Purchase Reversal | T5 | 3 -> 0 -> 8 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: 0 (FLAG) | ready |
| BR1_TS13_TC9 | TC-002364 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Completion timed out → Time-out Reversal → Completion resubmitted | T6 | 3 -> 0 -> Z -> 0 | 1: 2 (ASSERT) ; 2: no response expected ; 3: 0 (FLAG) ; 4: 0 (ASSERT) | requires_review |
| BR1_TS13_TC10 | TC-002365 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Authorization → Completion → Settlement | T8 | 3 -> 0 -> 990 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: ? (FLAG) | requires_review |
| BR1_TS13_TC11 | TC-002366 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Authorization released with Time-out Reversal → declined | T10 | 3 -> Z | 1: no response expected ; 2: 1 (FLAG) | requires_review |
| BR1_TS13_TC12 | TC-002367 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Authorization reversed with Purchase Reversal (8) → declined | T10 | 3 -> 8 | 1: 2 (ASSERT) ; 2: 1 (FLAG) | requires_review |
| BR1_TS13_TC13 | TC-002368 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Cancellation not matching the authorization → declined | T10 | 3 -> S | 1: 2 (ASSERT) ; 2: 1 (FLAG) | requires_review |
| BR1_TS13_TC14 | TC-002369 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Magnetic Stripe Expired card → rejected at device (no host message) | T11 | - | n/a (no host message) | ready |

### BR1_TS14 BUYPASS ATL105 MasterCard Credit Authorization Only – Contactless Magnetic Stripe (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS14_TC1 | TC-002370 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Authorization Only approved | T1 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS14_TC2 | TC-002371 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Partial authorization → Completion for approved amount | T4 | 3 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS14_TC3 | TC-002372 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Partial authorization → Cancellation | T4 | 3 -> S | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS14_TC4 | TC-002373 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Authorization → Completion | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS14_TC5 | TC-002374 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Pre-authorization → Completion for a different final amount | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (FLAG) | requires_review |
| BR1_TS14_TC6 | TC-002375 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Authorization → Cancellation | T5 | 3 -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS14_TC7 | TC-002376 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Authorization → Completion → Purchase Reversal | T5 | 3 -> 0 -> 8 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: 0 (FLAG) | ready |
| BR1_TS14_TC8 | TC-002377 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Completion timed out → Time-out Reversal → Completion resubmitted | T6 | 3 -> 0 -> Z -> 0 | 1: 2 (ASSERT) ; 2: no response expected ; 3: 0 (FLAG) ; 4: 0 (ASSERT) | requires_review |
| BR1_TS14_TC9 | TC-002378 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Magnetic Stripe Expired card → rejected at device (no host message) | T11 | - | n/a (no host message) | ready |

### BR1_TS15 BUYPASS ATL105 MasterCard Credit Authorization Only – Manual / Keyed (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS15_TC1 | TC-002379 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Authorization Only approved | T1 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS15_TC2 | TC-002380 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed 3 failed swipes → keyed entry → approved | T2 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS15_TC3 | TC-002381 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Partial authorization → Completion for approved amount | T4 | 3 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS15_TC4 | TC-002382 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Partial authorization → Cancellation | T4 | 3 -> S | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS15_TC5 | TC-002383 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Authorization → Completion | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS15_TC6 | TC-002384 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Pre-authorization → Completion for a different final amount | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (FLAG) | requires_review |
| BR1_TS15_TC7 | TC-002385 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Authorization → Cancellation | T5 | 3 -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS15_TC8 | TC-002386 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Authorization → Completion → Purchase Reversal | T5 | 3 -> 0 -> 8 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: 0 (FLAG) | ready |
| BR1_TS15_TC9 | TC-002387 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Completion timed out → Time-out Reversal → Completion resubmitted | T6 | 3 -> 0 -> Z -> 0 | 1: 2 (ASSERT) ; 2: no response expected ; 3: 0 (FLAG) ; 4: 0 (ASSERT) | requires_review |
| BR1_TS15_TC10 | TC-002388 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Manual / Keyed Expired card → rejected at device (no host message) | T11 | - | n/a (no host message) | ready |

### BR1_TS16 BUYPASS ATL105 MasterCard Credit Authorization Only – Chip Fallback (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS16_TC1 | TC-002389 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Authorization Only approved | T1 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS16_TC2 | TC-002390 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Chip unreadable → keyed fallback (79) → approved | T2 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS16_TC3 | TC-002391 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Partial authorization → Completion for approved amount | T4 | 3 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | needs_client_input |
| BR1_TS16_TC4 | TC-002392 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Partial authorization → Cancellation | T4 | 3 -> S | 1: F (ASSERT) ; 2: 0 (FLAG) | needs_client_input |
| BR1_TS16_TC5 | TC-002393 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Authorization → Completion | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS16_TC6 | TC-002394 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Pre-authorization → Completion for a different final amount | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (FLAG) | requires_review |
| BR1_TS16_TC7 | TC-002395 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Authorization → Cancellation | T5 | 3 -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS16_TC8 | TC-002396 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Authorization → Completion → Purchase Reversal | T5 | 3 -> 0 -> 8 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: 0 (FLAG) | ready |
| BR1_TS16_TC9 | TC-002397 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Chip Fallback Completion timed out → Time-out Reversal → Completion resubmitted | T6 | 3 -> 0 -> Z -> 0 | 1: 2 (ASSERT) ; 2: no response expected ; 3: 0 (FLAG) ; 4: 0 (ASSERT) | requires_review |

### BR1_TS17 BUYPASS ATL105 MasterCard Credit Authorization Only – Credential on File (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS17_TC1 | TC-002398 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Credential on File Authorization Only approved | T1 | 3 | 1: 2 (ASSERT) | ready |
| BR1_TS17_TC2 | TC-002399 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Credential on File Authorization → Completion | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) | ready |
| BR1_TS17_TC3 | TC-002400 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Credential on File Pre-authorization → Completion for a different final amount | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (FLAG) | requires_review |
| BR1_TS17_TC4 | TC-002401 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Credential on File Authorization → Cancellation | T5 | 3 -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS17_TC5 | TC-002402 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Credential on File Authorization → Completion → Purchase Reversal | T5 | 3 -> 0 -> 8 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: 0 (FLAG) | ready |
| BR1_TS17_TC6 | TC-002403 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Credential on File Completion timed out → Time-out Reversal → Completion resubmitted | T6 | 3 -> 0 -> Z -> 0 | 1: 2 (ASSERT) ; 2: no response expected ; 3: 0 (FLAG) ; 4: 0 (ASSERT) | requires_review |

### BR1_TS18 BUYPASS ATL105 MasterCard Credit Authorization Only – Contactless Mobile Commerce Device (unconfirmed)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS18_TC1 | TC-002404 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Mobile Commerce Device Authorization Only approved | T1 | 3 | 1: 2 (ASSERT) | pending_sme |
| BR1_TS18_TC2 | TC-002405 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Mobile Commerce Device Partial authorization → Completion for approved amount | T4 | 3 -> 0 | 1: F (ASSERT) ; 2: 0 (ASSERT) | pending_sme |
| BR1_TS18_TC3 | TC-002406 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Mobile Commerce Device Partial authorization → Cancellation | T4 | 3 -> S | 1: F (ASSERT) ; 2: 0 (FLAG) | pending_sme |
| BR1_TS18_TC4 | TC-002407 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Mobile Commerce Device Authorization → Completion | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) | pending_sme |
| BR1_TS18_TC5 | TC-002408 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Mobile Commerce Device Pre-authorization → Completion for a different final amount | T5 | 3 -> 0 | 1: 2 (ASSERT) ; 2: 0 (FLAG) | pending_sme |
| BR1_TS18_TC6 | TC-002409 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Mobile Commerce Device Authorization → Cancellation | T5 | 3 -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | pending_sme |
| BR1_TS18_TC7 | TC-002410 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Mobile Commerce Device Authorization → Completion → Purchase Reversal | T5 | 3 -> 0 -> 8 | 1: 2 (ASSERT) ; 2: 0 (ASSERT) ; 3: 0 (FLAG) | pending_sme |
| BR1_TS18_TC8 | TC-002411 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Authorization Only – Contactless Mobile Commerce Device Completion timed out → Time-out Reversal → Completion resubmitted | T6 | 3 -> 0 -> Z -> 0 | 1: 2 (ASSERT) ; 2: no response expected ; 3: 0 (FLAG) ; 4: 0 (ASSERT) | pending_sme |

### BR1_TS19 BUYPASS ATL105 MasterCard Credit Mail/Phone Authorization Only – Manual / Keyed (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS19_TC1 | TC-002412 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Authorization Only – Manual / Keyed Mail/Phone Authorization Only approved | T1 | B | 1: 2 (ASSERT) | ready |
| BR1_TS19_TC2 | TC-002413 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Authorization Only – Manual / Keyed Mail/Phone Authorization → Cancellation | T5 | B -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | ready |
| BR1_TS19_TC3 | TC-002414 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Authorization Only – Manual / Keyed Mail/Phone Authorization → Completion | T5 | - | n/a (no host message) | blocked_spec_gap |

### BR1_TS20 BUYPASS ATL105 MasterCard Credit Mail/Phone Authorization Only – Credential on File (unconfirmed)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS20_TC1 | TC-002415 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Authorization Only – Credential on File Mail/Phone Authorization Only approved | T1 | B | 1: 2 (ASSERT) | pending_sme |
| BR1_TS20_TC2 | TC-002416 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Authorization Only – Credential on File Mail/Phone Authorization → Cancellation | T5 | B -> S | 1: 2 (ASSERT) ; 2: 0 (FLAG) | pending_sme |
| BR1_TS20_TC3 | TC-002417 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Mail/Phone Authorization Only – Credential on File Mail/Phone Authorization → Completion | T5 | - | n/a (no host message) | blocked_spec_gap |

### BR1_TS21 BUYPASS ATL105 MasterCard Credit Merchandise Return – EMV Contact Chip (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS21_TC1 | TC-002418 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – EMV Contact Chip Merchandise Return processed | T1 | 7 | 1: ? (FLAG) | ready |
| BR1_TS21_TC2 | TC-002419 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – EMV Contact Chip Merchandise Return → Void of a Merchandise Return | T5 | 7 -> U | 1: ? (FLAG) ; 2: 0 (FLAG) | ready |

### BR1_TS22 BUYPASS ATL105 MasterCard Credit Merchandise Return – EMV Contactless Chip (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS22_TC1 | TC-002420 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – EMV Contactless Chip Merchandise Return processed | T1 | 7 | 1: ? (FLAG) | ready |
| BR1_TS22_TC2 | TC-002421 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – EMV Contactless Chip Merchandise Return → Void of a Merchandise Return | T5 | 7 -> U | 1: ? (FLAG) ; 2: 0 (FLAG) | ready |

### BR1_TS23 BUYPASS ATL105 MasterCard Credit Merchandise Return – Magnetic Stripe (spec_implied)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS23_TC1 | TC-002422 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Magnetic Stripe Merchandise Return processed | T1 | 7 | 1: ? (FLAG) | ready |
| BR1_TS23_TC2 | TC-002423 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Magnetic Stripe Merchandise Return → Void of a Merchandise Return | T5 | 7 -> U | 1: ? (FLAG) ; 2: 0 (FLAG) | ready |

### BR1_TS24 BUYPASS ATL105 MasterCard Credit Merchandise Return – Contactless Magnetic Stripe (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS24_TC1 | TC-002424 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Contactless Magnetic Stripe Merchandise Return processed | T1 | 7 | 1: ? (FLAG) | ready |
| BR1_TS24_TC2 | TC-002425 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Contactless Magnetic Stripe Merchandise Return → Void of a Merchandise Return | T5 | 7 -> U | 1: ? (FLAG) ; 2: 0 (FLAG) | ready |

### BR1_TS25 BUYPASS ATL105 MasterCard Credit Merchandise Return – Manual / Keyed (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS25_TC1 | TC-002426 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Manual / Keyed Merchandise Return processed | T1 | 7 | 1: ? (FLAG) | ready |
| BR1_TS25_TC2 | TC-002427 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Manual / Keyed Merchandise Return → Void of a Merchandise Return | T5 | 7 -> U | 1: ? (FLAG) ; 2: 0 (FLAG) | ready |

### BR1_TS26 BUYPASS ATL105 MasterCard Credit Merchandise Return – Chip Fallback (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS26_TC1 | TC-002428 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Chip Fallback Merchandise Return processed | T1 | 7 | 1: ? (FLAG) | ready |
| BR1_TS26_TC2 | TC-002429 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Chip Fallback Merchandise Return → Void of a Merchandise Return | T5 | 7 -> U | 1: ? (FLAG) ; 2: 0 (FLAG) | ready |

### BR1_TS27 BUYPASS ATL105 MasterCard Credit Merchandise Return – Credential on File (unconfirmed)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS27_TC1 | TC-002430 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Credential on File Merchandise Return processed | T1 | 7 | 1: ? (FLAG) | pending_sme |
| BR1_TS27_TC2 | TC-002431 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Credential on File Merchandise Return → Void of a Merchandise Return | T5 | 7 -> U | 1: ? (FLAG) ; 2: 0 (FLAG) | pending_sme |

### BR1_TS28 BUYPASS ATL105 MasterCard Credit Merchandise Return – Contactless Mobile Commerce Device (unconfirmed)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS28_TC1 | TC-002432 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Contactless Mobile Commerce Device Merchandise Return processed | T1 | 7 | 1: ? (FLAG) | pending_sme |
| BR1_TS28_TC2 | TC-002433 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Merchandise Return – Contactless Mobile Commerce Device Merchandise Return → Void of a Merchandise Return | T5 | 7 -> U | 1: ? (FLAG) ; 2: 0 (FLAG) | pending_sme |

### BR1_TS29 BUYPASS ATL105 MasterCard Credit Balance Inquiry – EMV Contact Chip (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS29_TC1 | TC-002434 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Balance Inquiry – EMV Contact Chip Balance Inquiry answered | T1 | E | 1: ? (FLAG) | ready |

### BR1_TS30 BUYPASS ATL105 MasterCard Credit Balance Inquiry – EMV Contactless Chip (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS30_TC1 | TC-002435 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Balance Inquiry – EMV Contactless Chip Balance Inquiry answered | T1 | E | 1: ? (FLAG) | ready |

### BR1_TS31 BUYPASS ATL105 MasterCard Credit Balance Inquiry – Magnetic Stripe (spec_implied)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS31_TC1 | TC-002436 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Balance Inquiry – Magnetic Stripe Balance Inquiry answered | T1 | E | 1: ? (FLAG) | ready |

### BR1_TS32 BUYPASS ATL105 MasterCard Credit Balance Inquiry – Contactless Magnetic Stripe (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS32_TC1 | TC-002437 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Balance Inquiry – Contactless Magnetic Stripe Balance Inquiry answered | T1 | E | 1: ? (FLAG) | ready |

### BR1_TS33 BUYPASS ATL105 MasterCard Credit Balance Inquiry – Manual / Keyed (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS33_TC1 | TC-002438 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Balance Inquiry – Manual / Keyed Balance Inquiry answered | T1 | E | 1: ? (FLAG) | ready |

### BR1_TS34 BUYPASS ATL105 MasterCard Credit Balance Inquiry – Chip Fallback (valid)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS34_TC1 | TC-002439 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Balance Inquiry – Chip Fallback Balance Inquiry answered | T1 | E | 1: ? (FLAG) | ready |

### BR1_TS35 BUYPASS ATL105 MasterCard Credit Balance Inquiry – Credential on File (unconfirmed)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS35_TC1 | TC-002440 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Balance Inquiry – Credential on File Balance Inquiry answered | T1 | E | 1: ? (FLAG) | pending_sme |

### BR1_TS36 BUYPASS ATL105 MasterCard Credit Balance Inquiry – Contactless Mobile Commerce Device (unconfirmed)

| TC | ID | Test case | Type | Steps (Transaction Type) | Expected response | Status |
|---|---|---|---|---|---|---|
| BR1_TS36_TC1 | TC-002441 | BUYPASS ATL105 MasterCard Credit MERCHANT 01 (POS PLACEHOLDER) Balance Inquiry – Contactless Mobile Commerce Device Balance Inquiry answered | T1 | E | 1: ? (FLAG) | pending_sme |

## Planned but not generated

- BR1_TS3 T10-PARTIAL-CAT: M01: template runs on ['CAT'] terminals only
